let img1;
let img2;

function setup() {
  createCanvas(400, 400);
  background(220);  
}

function preload(){
   img1 = loadImage('./assets/snowflakes.png'); //https://www.flaticon.com/free-icon/snowflake_13117733
   img2 = loadImage('./assets/snowman.png'); //https://www.flaticon.com/free-icon/snowman_3737462
}

function draw() {
   
   background(220);
   image(img1, 0, 0, 400, 400);

   textFont('Gotham');
   textSize(20);
   fill(0, 0, 0);
   stroke(0, 0, 0);
   text('And a Happy New Year', 100, 350, [250], [100]);

   fill(0, 0, 0);
   stroke(0, 0, 0);
   text('Happy Holidays', 135, 25, [150], [45]);

   if (mouseX < 200 && mouseY < 200){
      scale(0.25);
      image(img2, 600, 600, 350, 350);
   } else {
      image(img2, 25, 50, 350, 350);
   }

   
}