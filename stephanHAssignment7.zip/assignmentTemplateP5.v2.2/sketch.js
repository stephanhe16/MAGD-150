let ballX = [];
let ballY = [];
let ballPosition = [];

function setup() {
  createCanvas(400, 400);
  background(220);
  for (let k = 0; k < 8; k++){
    ballX.push(random(10, width - 50));
    ballY.push(random(10, height - 50));
  }
  
  
  let ball1 = random(ballX);
  let ball2 = random(ballY);
  
  text("Array 1: " + ballX[0, 4], 50, 100);
  text("Array 2: " + ballY[0, 4], 50, 150);
  text("Random 1: " + ball1, 50, 200);
  text("Random 2: " + ball2, 50, 250);
  
  for (let r = 0; r < 5; r++){
    let num = Math.floor(random(0, ballX.length));
    ballPosition.push(ballX[num]);
    ballPosition.push(ballY[num]);
    ballX.splice(num, 1);
    ballY.splice(num, 1);
  }
  console.log(ballPosition);
  
  let num2 = random(ballPosition);
  
  text("Random 1 & 2: " + num2, 50, 300);
  
}