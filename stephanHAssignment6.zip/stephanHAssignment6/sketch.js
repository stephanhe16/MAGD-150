let num = 60;
let ballPosition = [];

function setup() {
   createCanvas(400,400);
   for(let i=0;i<num; i++){
     ballPosition[i] = [];
     for (let p=0; p<2; p++){
       ballPosition[i][p] = -100;
     }
   }
   console.log(ballPosition);
}
function draw() {
  background(0);
  fill(255);
  noStroke();
  ballPosition[ballPosition.length-1][0] = mouseX;
  ballPosition[ballPosition.length-1][1] = mouseY;
  for (let r=0; r<ballPosition.length-1; r++){
    for(let s = 0; s<5; s++){
      
      ballPosition[r][s] = ballPosition[r++][s];
    }
  }
  for(let i=0; i<num; i++){
    circle(ballPosition[i][0], ballPosition[i][1], 30);
  }
}
